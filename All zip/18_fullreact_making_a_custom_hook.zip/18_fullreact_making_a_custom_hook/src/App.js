// under React v17, you must add : import React from 'react';
// import logo from './logo.svg'; Original logo in a blank project
// import './App.css'; we will use the index.css global stylesheet
import Navbar from './Navbar'; // import Navbar component
// Before launching, you must run another Terminal to launch Json Server
// and type : npx json-server --watch data/db.json --port 8000

import Content from './Content'; // import Content component

function App() {

  return (
    <div className="App">

      {/* Navbar Component nesting*/}
      <Navbar />

      {/* Custom homepage template */}
      <div className="content">
        {/* Content Component nesting*/}
        <Content />
      </div>
    </div>
  );
}

export default App; // To be usable by another component