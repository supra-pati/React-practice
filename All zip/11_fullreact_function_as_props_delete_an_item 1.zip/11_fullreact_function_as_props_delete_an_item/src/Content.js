import { useState } from "react"; // useState import to manage reactive var
import BlogList from "./BlogList";

// Parent Component
const Content = () => {

    // Blog List declaration
    const [blogs, setBlogs] = useState([
        {id:1, title:'Blog#1', body:'Lorem ipsum ...', author:'Author#1'},
        {id:2, title:'Blog#2', body:'Lorem ipsum ... Lorem ipsum ...', author:'Author#2'},
        {id:3, title:'Blog#3', body:'Lorem ipsum ... Lorem ipsum ... Lorem ipsum ...', author:'Author#3'}
    ]);

    // Delete button Listener passed as a prop in BlogList object. Not delete the current list above, just for display
    const handleDelete = (id) => {
        const newBlogList = blogs.filter((blog) => blog.id !== id);
        setBlogs(newBlogList);
    }

    return (    
        <div className="content">
            <BlogList blogs={blogs} title='Blogs List' handleDelete={handleDelete}/> {/* Child Component with prop named blogs */}
        </div>
     );
}

export default Content;