import { useParams } from "react-router-dom/cjs/react-router-dom";
import useFetch from "./useFetch";
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";

const BlogDetails = () => {

    const { id } = useParams(); // To grab parameters from the route
    const {data : blog, isLoading, error } = useFetch('http://localhost:8000/blogs/' + id) // Reusing useFetch.js component

    // Invoke useHistory
    const history = useHistory();

    // Delete Handler
    const handleDelete = () => {
        fetch('http://localhost:8000/blogs/' + blog.id ,{
            method:'DELETE',
        }).then (()=>{
            history.push('/'); // Go to the route / (Home)
        });
    }

    return (
        <div className="blog-details">
            {isLoading && <div>Loading ... </div>}
            {error && <div>{ error }</div>}
            {blog && (
                <article>
                    <h2>{blog.title}</h2>
                    <p>Written by {blog.author}</p>
                    <div>{blog.content}</div>
                    <button onClick={handleDelete}>Delete Blog</button>
                </article>
            )}
        </div>
    );
}
 
export default BlogDetails;