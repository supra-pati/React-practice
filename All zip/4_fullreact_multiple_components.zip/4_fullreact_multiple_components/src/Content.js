const Content = () => {
    return ( 
        <div className="content">
            <h2>Content</h2>
        </div>
     );
}
 
export default Content;
<div className="content">
    <h2>Content</h2>
</div>