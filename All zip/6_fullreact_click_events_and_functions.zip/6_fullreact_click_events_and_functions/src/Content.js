const Content = () => {

    // Button Handler
    const handleClick = (e) => {
        console.log('Button clicked !', e ); // 'e' added to display event properties
    }

    // Button Handler w/ parameter
    const handleClickAgain = (name,e) => {
        console.log('Hello ' + name, e.target); // 'e' added to display event properties
    }

    return (    
        <div className="content">
        
            <h2>Content</h2>
        
            {/* Function reference */}
            <button onClick={handleClick}>Click me</button> 
            
            {/* Wrap in Anonymous Function */}
            <button onClick={(e) => { 
                handleClickAgain('User',e); // 'e' added to display event properties
            }
            }>Say Hello</button> 
        
        </div>
     );
}
 
export default Content;