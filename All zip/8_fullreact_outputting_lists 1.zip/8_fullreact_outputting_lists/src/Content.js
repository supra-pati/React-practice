import { useState } from "react"; // useState import to manage reactive var

const Content = () => {

    // Blog List declaration
    const [blogs, setBlogs] = useState([
        {id:1, title:'Blog#1', body:'Lorem ipsum ...', author:'Author#1'},
        {id:2, title:'Blog#2', body:'Lorem ipsum ... Lorem ipsum ...', author:'Author#2'},
        {id:3, title:'Blog#3', body:'Lorem ipsum ... Lorem ipsum ... Lorem ipsum ...', author:'Author#3'}
    ]);

    return (    
        <div className="content">
            {
                blogs.map( (blog) => ( // Using map method to display blog list
                    <div className="blog-preview" key={blog.id}> {/* adding blog style in index.css*/}
                        <h2>{blog.title}</h2>
                        <p>Written by : {blog.author}</p>
                    </div>
                )
                )
            }
        </div>
     );
}

export default Content;