import BlogList from "./BlogList";
import useFetch from "./useFetch";

// Parent Component / This function rerender the page
const Content = () => {

    // Custom Hook externalized. See useFetch.js
    // 'data' renamed 'blogs' for this 'useFetch Hook' caller
    const {data : blogs, isLoading, error } = useFetch('http://localhost:8000/blogs');

    return (    
        <div className="content">
            {/* Conditional Templating : if isLoading === true, display text 'Is loading ...*/}
            { error && <div style={{color:'red'}}>{error}</div> }
            {/* Conditional Templating : if isLoading === true, display text 'Is loading ...*/}
            { isLoading && <div style={{color:'darkgrey'}}>Is loading ...</div> }
            {/* Conditional Templating : Here we use javascript && : if left part of condition (blogs) is false, it do not consider the other part */}
            { blogs && <BlogList blogs={blogs} title='Blogs List' /> } {/* Child Component with prop named blogs */}
        </div>
     );
}

export default Content;