// under React v17, you must add : import React from 'react';
// Before launching, you must run another Terminal to launch Json Server
// and type : npx json-server --watch data/db.json --port 8000
// and install 'react-router-dom' : npm install react-router-dom@5
// To test type in Browser : http://localhost:3000/ (don't forget the '/' to test home route)
// Here we modify Navbar.js to manage links

import Navbar from './Navbar'; // import Navbar component
import Content from './Content'; // import 'Content.js' component
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'; 
import CreateBlog from './CreateBlog';

function App() {

  return (
    <Router> 
    <div className="App">
        {/* Navbar Component nesting*/}
        <Navbar />
        {/* Custom homepage template */}
        <div className="content">
          {/* Using Route*/}
          <Switch>
            <Route exact path="/"> {/* / for Home - 'exact' to avoid confusion with the '/' in '/createblog' route path */}
             <Content />
            </Route>
            <Route path="/createblog"> {/* for Create Blog - Add it in <a href=""> in Navbar.js */} 
             <CreateBlog/>
            </Route>
          </Switch>
          {/* Old method Content Component was only nested in a <div>
          <Content /> */}
        </div>
    </div>
    </Router>
  );
}

export default App; // To be usable by another component