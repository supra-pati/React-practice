// nb : Custom Hook name in React must begin with the word 'use' otherwise it won't work
import { useState, useEffect } from "react";

const useFetch = (url) => { // 'url' as param to manage multiple endpoint url

// Blog List declaration
    // Data will come now from data/db.json, so empty at first, will be fed next
    const [data, setData] = useState(null); 
    // isLoading useState
    const [isLoading, setIsLoading] = useState(true);
    // to display error on screen
    const [error, setError] = useState(null);

    // The rerender trigger this function 
    // useEffect return nothing
    // The arrow function trigger at once & according to a dependencies array as 2nd argument
    // an empty dependencies array make sure that the function is executed only after the 1st rendering
    
    useEffect( () => {

        // Abort Controller to manage 'useFetch.js' execution
        const abortController = new AbortController();

        setTimeout( () => { // Just to see the 'IsLoading ...' message, simulate real feeding from server
            fetch(url, {signal: abortController.signal}) // Link the Fetch to the abortController
            .then (res => {
                if (!res.ok) { // if server response is not ok, this Error message will be send to err.message in the catch
                    throw Error('Could not fetch the data for that resource');
                }
                return res.json();
            })
            .then (data => {
                console.log(data);
                setData(data);
                setIsLoading(false); // To hide 'IsLoading ...' text when data are loaded
                setIsLoading(null); // Reinitialize isLoading status if there was an error before
            })
            .catch (err => { // To catch errors from server. You can try it by stopping json.server
                if (err.name === 'AbortError') { // To detect Abort execution
                    console.log('Fetch aborted');
                } else { // Manage others errors
                    setIsLoading(false); // To hide 'IsLoading ...' if there's an error
                    setError(err.message);
                }
            });
        },1000);

        // Abort the Fetch 
        return () => abortController.abort();

    },[url]);

    // return data to the caller (here Content.js)
    return {data, isLoading, error}
}
 
export default useFetch;