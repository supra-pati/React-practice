// import logo from './logo.svg'; Original logo in a blank project
import './App.css';
// under React v17, you must add : import React from 'react';

function App() {
  return (
    <div className="App">

      {/* Custome homepage template */}
      <div className="content">
        <h1>App Component</h1>
      </div>

      {/* Original .JSX in a blank project
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
  */}
    </div>
  );
}

export default App; // To be usable by another component
