import { useState, useEffect } from "react"; // useState import to manage reactive var & 
import BlogList from "./BlogList";

// Parent Component / This function rerender the page
const Content = () => {

    // Blog List declaration
    // Data will come now from data/db.json, so empty at first, will be fed next
    const [blogs, setBlogs] = useState(null); 

    // isLoading useState
    const [isLoading, setIsLoading] = useState(true);


    // The rerender trigger this function 
    // useEffect return nothing
    // The arrow function trigger at once & according to a dependencies array as 2nd argument
    // an empty dependencies array make sure that the function is executed only after the 1st rendering
    useEffect( () => {
        setTimeout( () => { // Just to see the 'IsLoading ...' message, simulate real feeding from server
            fetch('http://localhost:8000/blogs')
            .then (res => {
                return res.json();
            })
            .then (data => {
                console.log(data);
                setBlogs(data);
                setIsLoading(false); // To hide 'IsLoading ...' text when data are loaded
            });
        },1000);
    },[]);

    return (    
        <div className="content">
            {/* Conditional Templating : if isLoading === true, display text 'Is loading ...*/}
            {isLoading && <div style={{color:'red'}}>Is loading ...</div>}
            {/* Conditional Templating : Here we use javascript && : if left part of condition (blogs) is false, it do not consider the other part */}
            {blogs && <BlogList blogs={blogs} title='Blogs List' />} {/* Child Component with prop named blogs */}
        </div>
     );
}

export default Content;