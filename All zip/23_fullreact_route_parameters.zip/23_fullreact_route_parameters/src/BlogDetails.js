import { useParams } from "react-router-dom/cjs/react-router-dom";

const BlogDetails = () => {

    const { id } = useParams(); // To grab parameters from the route

    return (
        <div className="blog-details">
            <h2>Blog Details #{id}</h2>
        </div>
    );
}
 
export default BlogDetails;