// Don't remember to add it in App.js as component & as route & in navbar.js

const CreateBlog = () => {
    return (
     <div className="createBlog">
         <h2>Add a New Blog</h2>
     </div>
    );
 }
  
 export default CreateBlog;