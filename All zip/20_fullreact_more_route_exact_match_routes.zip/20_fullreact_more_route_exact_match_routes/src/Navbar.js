const Navbar = () => {
    return (
        <nav className="navbar">
            <h1>Blogs Place</h1>
            <div className="links">
                <a href="/">Home</a>
                <a href="/createblog" style={{ // Inline Styling
                    color:'white',
                    backgroundColor: '#0071AD',
                    borderRadius:'8px'
                }}>New Blog</a>
            </div>
        </nav>
    );
}

export default Navbar;  