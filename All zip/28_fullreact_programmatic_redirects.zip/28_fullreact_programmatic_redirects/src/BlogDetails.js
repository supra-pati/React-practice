import { useParams } from "react-router-dom/cjs/react-router-dom";
import useFetch from "./useFetch";

const BlogDetails = () => {

    const { id } = useParams(); // To grab parameters from the route
    const {data : blog, isLoading, error } = useFetch('http://localhost:8000/blogs/' + id) // Reusing useFetch.js component

    return (
        <div className="blog-details">
            {isLoading && <div>Loading ... </div>}
            {error && <div>{ error }</div>}
            {blog && (
                <article>
                    <h2>{blog.title}</h2>
                    <p>Written by {blog.author}</p>
                    <div>{blog.content}</div>
                </article>
            )}
        </div>
    );
}
 
export default BlogDetails;