import { useState } from "react"; // useState import to manage reactive var

const Content = () => {

    // var declaration
    //let name ='Buzonie';
    const [lastName, setLastName] = useState('Buzonie'); // reactive var declaration + set function
    const [firstName, setFirstName] = useState('Christophe'); // reactive var declaration + set function
    const [age, setAge] = useState(56);

    // Button Handler
    const handleClick = () => {
        setLastName('YourLastName');
        setFirstName('YourFirstName');
        setAge(30);
    }

    return (    
        <div className="content">
        
            <h2>Content</h2>
            <p>Last Name : {lastName} - First Name : {firstName} - Age : {age}</p>
            {/* Function reference */}
            <button onClick={handleClick}>Click me</button> 

        </div>
     );
}
 
export default Content;