// Don't remember to add it in App.js as component & as route & in navbar.js

import { useState } from "react";

const CreateBlog = () => {

    // To monitor form values
    const [title, setTitle] = useState('');
    const [author, setAuthor] = useState('Author#1'); // select an initial value
    const [content, setContent] = useState('');

    return (
     <div className="createBlog">
         <h2>Add a New Blog</h2>
         <form>
            <label>Title : </label>
            <input
                type='text'
                value = {title} // The value match the useState
                onChange = { (e) => setTitle(e.target.value)} // To change the value in the useState
                required
            />

            <label>Author : </label>
            <select name="blog_author"
                value = {author} // The value match the useState
                onChange = { (e) => setAuthor(e.target.value)} // To change the value in the useState
            >
                <option value="Author#1">Author#1</option>
                <option value="Author#2">Author#2</option>
                <option value="Author#3">Author#3</option>
            </select>

            <label>Content : </label>
            <textarea 
                name="blog_content"
                cols="30"
                rows="10"
                value = {content} // The value match the useState
                onChange = { (e) => setContent(e.target.value)} // To change the value in the useState
                required
            >
            </textarea>

            <button>Add Blog</button>
            
            {/* Debug
            <p></p>
            { title }
            <p></p>
            { author }
            <p></p> 
            { content }
            */}
            
         </form>
     </div>
    );
 }
  
 export default CreateBlog;