import { Link } from 'react-router-dom';

const Navbar = () => {
    return (
        <nav className="navbar">
            <h1>Blogs Place</h1>
            <div className="links">
                <Link to="/">Home</Link> {/* Prevent to make a new request to the server*/}
                <Link to="/createblog" style={{ // Inline Styling
                    color:'white',
                    backgroundColor: '#0071AD',
                    borderRadius:'8px'
                }}>New Blog</Link>
            </div>
        </nav>
    );
}

export default Navbar;  