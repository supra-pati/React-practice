
const BlogList = ({blogs, title, handleDelete}) => { // to receive blogs object

    //const blogs = props.blogs; // blogs property
    //const title = props.title; // title property
    //console.log (props, blogs);

    return (
        <div className="blog-list">
            <h2>{title}</h2> 
            {
                blogs.map( (blog) => ( // Using map method to display blog list
                    <div className="blog-preview" key={blog.id}> {/* 'key' allow to browse the Blog List */}
                        <h2>{blog.title}</h2>
                        <p>Written by : {blog.author}</p>
                        <button onClick={()=> handleDelete(blog.id)}>Delete Blog</button>
                    </div>
                )
                )
            }
        </div>
      );
}
 
export default BlogList;