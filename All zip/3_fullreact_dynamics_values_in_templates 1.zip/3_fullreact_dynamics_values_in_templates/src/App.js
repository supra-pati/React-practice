// import logo from './logo.svg'; Original logo in a blank project
import './App.css';
// under React v17, you must add : import React from 'react';

function App() {

  const title ="Welcome to the new blog"; // const 'title' declaration
  const likes =50;
  const person = {name : 'Buzonie', age:56};
  const url = "https://www.google.com";

  return (
    <div className="App">

      {/* Custom homepage template */}
      <div className="content">
        <h1>{title}</h1> {/* dynamic display of 'title' */}
        <p>{likes} liked</p>
        <p>Name : {person.name} - Age : {person.age}</p> {/* Display person Obj properties */}
        <p>{10}</p> {/* Others example */}
        <p>{"hello world"}</p>
        <p>[0,1,3,4,5]</p>
        <p>{Math.random() *10}</p>
        <p><a HREF={url}>Google</a></p>
      </div>

      {/* Original .JSX in a blank project
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
  */}
    </div>
  );
}

export default App; // To be usable by another component

