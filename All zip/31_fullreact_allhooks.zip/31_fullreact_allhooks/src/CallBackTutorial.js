import React from "react";
import { useState, useCallback } from "react"; // adding useCallback hook
import ChildComponent from "./ChildComponent"; // See Child.js

function CallBacktutorial () {

    // Var states
    const [toggle, setToggle] = useState(false);
    const [apiData, setApiData] = useState("Lorem Ipsum ...");
    
    // Callback
    const returnComment = useCallback(
        (name) => { 
            return apiData + name;
        },
        [apiData] // Trigger only if ApiData change
    );

    // Button listener
    const buttonListener = () => {
        setToggle(!toggle);
    }

    return (
        <div>
            <h1>Hello CallBackTutorial !</h1>
            <ChildComponent returnComment={returnComment} />
            <button onClick={buttonListener}>{" "} Toggle</button>
            {toggle && <h1> toggle </h1>}
        </div>
    );
}
 
export default CallBacktutorial;