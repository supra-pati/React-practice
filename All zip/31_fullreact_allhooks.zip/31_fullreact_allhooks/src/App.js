import './App.css';
import StateTutorial from './StateTutorial';
import ReducerTutorial from './ReducerTutorial';
import EffectTutorial from './EffectTutorial';
import RefTutorial from './RefTutorial';
import LayoutEffectTutorial from './LayoutEffectTutorial';
import ImperativeHandle from './ImperativeHandle';
import ContextTutorial from './ContextTutorial';
import MemoTutorial from './MemoTutorial';
import CallBacktutorial from './CallBackTutorial';

function App() {
  return (
    <div className="App">
      <StateTutorial />
      <ReducerTutorial />
      <EffectTutorial />
      <RefTutorial/>
      <LayoutEffectTutorial />
      <ImperativeHandle />
      <ContextTutorial />
      <MemoTutorial />
      <CallBacktutorial />
    </div>
  );
}

export default App;
