// Usefull Hook when passing a lot of props

import React, { useState, createContext } from "react"; // import createContext here
import Login from "./Login";
import User from "./User";

export const AppContext = createContext(null); // Create a collection of State and make it visible for User & Login component (export)

function ContextTutorial() {
  const [username, setUsername] = useState(""); 

  return (
    <div>
        <h1>Hello ContextTutorial !</h1>
    <AppContext.Provider value={{ username, setUsername }}> {/* Passing all the components states to the Context */}
      <Login /> <User />
    </AppContext.Provider>
    </div>
  );
}

export default ContextTutorial;