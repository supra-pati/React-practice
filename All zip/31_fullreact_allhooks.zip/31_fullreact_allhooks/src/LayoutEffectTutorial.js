import React, {useLayoutEffect, useEffect, useRef} from "react";

function LayoutEffectTutorial () {

    const inputRef = useRef(null);

    useEffect( () => { // Called AFTER rendering & AFTER useLayoutEffect
        //console.log("UseEffect");
        console.log(inputRef.current.value);
    },[]);

    useLayoutEffect( () => { // Even if it's code AFTER UseEffect, it is called 1ST & called BEFORE rendering
        //console.log("UseLayoutEffect");
        inputRef.current.value = "Hello";
    },[]);

    return ( 
        <div className="App">
            <h1>Hello UseLayoutEffect !</h1>
            <p></p>
            <input defaultValue="Christophe" style={{width:400, height:20}} ref={inputRef} />
            <p></p>
        </div>
     );
}

export default LayoutEffectTutorial;