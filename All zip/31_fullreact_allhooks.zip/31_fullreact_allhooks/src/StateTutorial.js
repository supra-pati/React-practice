import React from 'react';
import { useState } from 'react';

const StateTutorial = () => {

    // let counter = 0; // WITHOUT USESTATE
    const [counter, setCounter] = useState(0); // WITH USESTATE

    // Other example 
    const [inputValue, setInputValue] = useState('Christophe');

    // Button Listener
    const increment = (event) => {
        //   counter ++; // WITHOUT USESTATE
        console.log (event);
        if (event.detail === 1) { // Single Click
            setCounter(counter + 1);
        } else if (event.detail === 2) { // Double Click
            setCounter(counter + 20);
        }

        //setCounter(counter + 1); // WITH USESTATE
        console.log(counter);
    }

    // Input Listener
    const changeInputValue = (event) => {
        const newValue = event.target.value;
        setInputValue(newValue);
    }

    return (
    <div>
        <h1>Hello UseState !</h1>
        <div>{counter}</div>
        <p></p>
        <button onClick={increment}>Increment</button>
        <p></p>
        <input placeholder="Type something ..." onChange={changeInputValue}/>
        <p>{inputValue}</p>
        

    </div>
    );
}
 
export default StateTutorial;