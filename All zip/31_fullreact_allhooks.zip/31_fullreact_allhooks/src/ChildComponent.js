import React, {useEffect} from "react";

function ChildComponent ({returnComment}) {

    useEffect(() => {
        console.log("Function called !");
    },[returnComment]); // Return a Function

    return (
        <div>{returnComment(" Christophe")}</div>
    );
}

export default ChildComponent;