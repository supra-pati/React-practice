import React, { useRef } from "react";

const RefTutorial = () => {
    
    // page element useRef declaration
    //const inputRef = useRef(null); // when start value is nothing
    const inputRef = useRef(null);

    // Click Listener
    const clickListener = () => {
        console.log("Button is clicked !");
        console.log(inputRef.current); // Access to the TAG Input Text
        console.log(inputRef.current.value); // Access to the Input Text VALUE
        inputRef.current.focus(); // When button is clicked, give user focus on Input TAG
        inputRef.current.value = ""; // To clear the value of the Input TAG
    };

    return (
        <div>
            <h1>Hello UseRef !</h1>
            <p></p>
            <input type="text" placeholder="Type something ..." ref={inputRef} />
            <p></p>
            <button onClick={clickListener}>Change</button>
            <p></p>
        </div>
    );
}
 
export default RefTutorial;