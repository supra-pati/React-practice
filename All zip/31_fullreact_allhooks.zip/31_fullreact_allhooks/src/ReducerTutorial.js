import React, { useReducer } from 'react';

const ReducerTutorial = () => {

    const reducer = (state, action) => {
        switch (action.type) {
            case "INCREMENT" :
                return {
                    count: state.count +1,
                    showText : state.showText
                }
            case "TOGGLESHOWTEXT" :
                return {
                    count: state.count +1,
                    showText : !state.showText
                }
            default:
                return state
        }
    }

    const [state, dispatch] = useReducer(
        reducer, {
            count : 0,
            showText : true
        }
    );

    const onClickReduce = () => {
        dispatch(
            { type: "INCREMENT" }
        );
        dispatch(
            { type: "TOGGLESHOWTEXT" }
        );
    }

    return ( 
        <div>
            <h1>Hello UseReducer !</h1>
            <p>{state.count}</p>
            <button onClick={onClickReduce}>Click here</button>
            {/* Conditional Template */}
            { state.showText && <p>Show Text is true</p>}
        </div>
      );
}
 
export default ReducerTutorial;