import React, { useContext } from "react"; // Import useContext To use the Context
import { AppContext } from "./ContextTutorial"; // Context created in ContextTutorial.js

function Login() {
  const { setUsername } = useContext(AppContext); // Grab setUsername from created context AppContext

  return (
    <div>
      <input placeholder="Type a username"
        onChange={(event) => {
          setUsername(event.target.value);
        }}
      />
    </div>
  );
}

export default Login;