// For using in a of hug computation
import React, { useEffect, useState, useMemo } from "react";
import Axios from "axios";

function MemoTutorial () {

    // ApiData state
    const [apiData, setApiData] = useState(null);
    // Button Toggle state
    const [toggle, setToggle] = useState(false);

    // To retrieve Api Data
    useEffect(() => {
        Axios
        .get('https://jsonplaceholder.typicode.com/comments')
        .then ((response) => {
            setApiData(response.data);
        });
    },[]);

    // Function to search longest name in retrieved data from api
    const findLongestName = (comments) => {
        if(!comments) return null;  

        let longestName = "";
        for (let i=0; i<comments.length; i++) {
            let currentName = comments[i].name;
            if (currentName.length > longestName.length) {
                longestName = currentName;
            }
        }
        console.log ('This was computed !');
        return longestName;
    }

    // 'Memoized' Function
    // [] is the dependency Array like in useEffect. Here the value apiData to avoid reloading when data are not changed
    const getLongestName = useMemo(() => findLongestName(apiData), [apiData]); 

    return ( 
        <div className="App">
            <h1>Hello MemoTutorial !</h1>
            {/* <p>{findLongestName(apiData)}</p> // Function always executed when rendering the page */}
            <div> {getLongestName} </div>
            <button
                onClick={() => {
                    setToggle(!toggle);
                }}
            >
                {" "}
                Toggle
            </button>
            {toggle && <h1> toggle </h1>}
        </div>
     );
}

export default MemoTutorial;