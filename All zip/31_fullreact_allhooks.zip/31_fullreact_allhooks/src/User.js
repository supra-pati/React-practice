import React, { useContext } from "react"; // Import useContext To use the Context
import { AppContext } from "./ContextTutorial"; // Context created in ContextTutorial.js

function User() {
  const { username } = useContext(AppContext); // Grab username from created context AppContext

  return (
    <div>
      {username} 
    </div>
  );
}

export default User;