// Import forwardRef to accept a reference from a Parent
import React, { forwardRef, useImperativeHandle, useState } from "react";

const Button = forwardRef((props, ref) => {

    // Toggle status of the Child button
    const [toggle, setToggle] = useState(false);
    
    // // Button Listener
    // const clickListener = () => {
    //     console.log("Child Button is clicked !");
    //     //setToggle (!toggle);
    // };

    // UseImperativeHandle
    useImperativeHandle ( ref, () => ({
        alterToggle() {
            setToggle (!toggle);
        },
    }));

  return (
    <>
      {/* <button onClick={clickListener}>Button From Child</button> // No need onClick() in this case*/} 
      <button>Button From Child</button>
      <p></p>
      {toggle && <span>Button Toggled</span>}
      <p></p>
    </>
  );
});

export default Button;