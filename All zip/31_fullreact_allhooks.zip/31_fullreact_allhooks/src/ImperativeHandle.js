import React, {useRef} from 'react';
import Button from './Button';

// Warning it's a Function
function ImperativeHandle () {

    const childButtonRef = useRef(null); // Can't pass this Reference to the Child Button
    
    // Parent Button Listener call alterToggle in <Button> component
    const parentClickListner = () => {
        console.log("Parent Button is clicked !");
        childButtonRef.current.alterToggle();
    }

    return (
        <div>
            <h1>Hello ImperativeHandle !</h1>
            <p></p>
            <button onClick={parentClickListner}>Button from Parent</button>
            <p></p>
            <Button ref={childButtonRef}/>
            <p></p>
        </div>
      );
}
 
export default ImperativeHandle;