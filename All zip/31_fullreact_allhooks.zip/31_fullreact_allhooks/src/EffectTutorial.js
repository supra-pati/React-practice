// Before running this, install Axios : npm install axios

import React, {useEffect, useState} from "react";
import Axios from "axios";

const EffectTutorial = () => {
    
    const [apiData, setApiData] = useState("");
    const [counter, setCounter] = useState(0);

    // Button Listener
    const increment = (event) => {
        //   counter ++; // WITHOUT USESTATE
        console.log (event);
        if (event.detail === 1) { // Single Click
            setCounter(counter + 1);
        } else if (event.detail === 2) { // Double Click
            setCounter(counter + 20);
        }
        console.log(counter);
    }

    // Executed when the page renders
    useEffect(() => {
        //console.log("Hello World !");
        Axios
            .get("https://jsonplaceholder.typicode.com/comments")
            .then ((response) => {
                //console.log(response.data);
                setApiData(response.data[0].email);
            });
    //}, []); // Empty array of all states to avoid call once the API 
    },[counter]); // or pass a value (ex:count), to call the API when counter value change
    
    return ( 
        <div>
            <h1>Hello UseEffect !</h1>
            <div>Hello {apiData} !;</div>
            <p></p>
            <div>{counter}</div>
            <p></p>
            <button onClick={increment}>Increment</button>
            <p></p>
        </div>
    );
}
 
export default EffectTutorial;