import { useState, useEffect } from "react"; // useState import to manage reactive var & 
import BlogList from "./BlogList";

// Parent Component / This function rerender the page
const Content = () => {

    // Blog List declaration
    // Data will come now from data/db.json, so empty at first, will be fed next
    const [blogs, setBlogs] = useState(null); 

    // Delete button Listener passed as a prop in BlogList object.
    // Not delete the current list above, just for display


    // The rerender trigger this function 
    // useEffect return nothing
    // The arrow function trigger at once & according to a dependencies array as 2nd argument
    // an empty dependencies array make sure that the function is executed only after the 1st rendering
    useEffect( () => {
        fetch('http://localhost:8000/blogs')
        .then (res => {
            return res.json();
        })
        .then (data => {
            console.log(data);
            setBlogs(data);
        });
    },[]);

    return (    
        <div className="content">
            {/* Conditional Templating : Here we use javascript && : if left part of condition (blogs) is false, it do not consider the other part */}
            {blogs && <BlogList blogs={blogs} title='Blogs List' />} {/* Child Component with prop named blogs */}
        </div>
     );
}

export default Content;